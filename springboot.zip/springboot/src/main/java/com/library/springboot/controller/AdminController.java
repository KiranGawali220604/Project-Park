package com.library.springboot.controller;



import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.library.springboot.entities.Admin;
import com.library.springboot.entities.ProfilePicture;
import com.library.springboot.services.AdminService;
import com.library.springboot.services.MailServices;

@Controller
public class AdminController {

	private MailServices mailServices;
	
	private Admin admin;
	
	String generatedOtp;
	private AdminService adminService;
	
  	
	public  AdminController(MailServices mailServices,AdminService adminService) {
		this.mailServices=mailServices;
		this.adminService=adminService;
	}
	@GetMapping("/admin")
	public String getsignupForm(Model model) {
		model.addAttribute("admin", new Admin());
		return "signup";
	}
	
	@PostMapping("/submit")
	public String submitform(@ModelAttribute Admin admin ,Model model) {
		
	
		if(admin.getOtp() == null) {
		generatedOtp=mailServices.generateOtp();
		mailServices.sendOtp(admin.getEmail() ,generatedOtp);
		boolean isOtpSend=true;
		
		if(isOtpSend) {
			model.addAttribute("otpwindow","otp generated");
		}
	
		return "signup";
	}else {

		if(mailServices.verifyOtp(generatedOtp,admin.getOtp())) {
		adminService.saveAdmin(admin);
		model.addAttribute("success","account created sucessfully");
		return "signup";		
	}else {
	    System.out.println(generatedOtp);
		model.addAttribute("otpwindow", "otp generated");
		model.addAttribute("fail", "wrong otp enter again");
		return "signup";
	}
	}	
	}
	 @GetMapping("/adminlogin")
	 public String getAdminLogin() {
		 return "login";
	 }
	 
	@PostMapping("/login-status")
	public String getLoginStatus(@RequestParam("username") String username ,@RequestParam("password") String password, Model model){
		
		if(adminService.verifyLogin( username, password)) {
			admin = adminService.getAdminByUsername(username);
			return "test";
		}else {
			model.addAttribute("failed","incorrect username and password");
		
		return "redirect:/profile";
		
	}
	}
	@GetMapping("/profile")
	public String uploadProfile(Model model) {
		model.addAttribute("profile", new ProfilePicture());
		return "profile-pic";
	}
	@PostMapping("/upload-status")
	public String UploadStatus(MultipartFile file, @ModelAttribute ProfilePicture picture) throws IOException{
	 ProfilePicture image = new  ProfilePicture();
	 image.setAdmin(admin);
	 image.setImage(file.getBytes());
	 admin.setProfilePicture(image);
	 adminService.saveAdmin(admin);
	return generatedOtp;
	
}
}