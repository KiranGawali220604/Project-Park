package com.library.springboot.services;



import java.util.List;


import org.springframework.stereotype.Service;



import com.library.springboot.entities.Admin;
import com.library.springboot.repository.AdminRepository;

@Service
public class AdminService {

	
	private AdminRepository adminRepository;
	
    public AdminService( AdminRepository adminRepository) {
    this.adminRepository=adminRepository;
  

}
    public  Admin saveAdmin(Admin admin) {
    	return adminRepository.save(admin);
    	   
       }
    public boolean verifyLogin(String username,String password) {
    	List<Admin> all = adminRepository.findAll();
    	for(Admin ad : all) {
    		if((ad.getEmail().equals(username)) && (ad.getPassword().equals(password))) {
    			
    		return true;
    	      }else { 
             	return false;
    	      }
         }
		    return false;
    	   }
    public Admin getAdminByUsername(String username) {
    	return adminRepository.findByEmail(username);
    }
    }