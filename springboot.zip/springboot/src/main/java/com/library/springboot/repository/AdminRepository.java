package com.library.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.springboot.entities.Admin;

public interface AdminRepository extends JpaRepository <Admin, Integer>{

	public Admin findByEmail(String email);

	

}