package com.library.springboot.services;

import java.util.Random;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;





@Service
public class MailServices {
     
	
	private JavaMailSender javaMailSender;
	
	public MailServices(JavaMailSender javaMailSender) {
		this.javaMailSender=javaMailSender;
	}
	
	public String generateOtp() {
		Random rn = new Random();
		int nextInt = rn.nextInt(9999);
		String otp = Integer.toString(nextInt);
		
		return otp;
	}
	
	public void sendOtp(String email, String otp) {
		SimpleMailMessage message= new SimpleMailMessage();
		message.setTo(email);
		message.setSubject("otp for admin account");
		message.setText("OTP is:"+otp);
		javaMailSender.send(message);
		
	}

	public boolean verifyOtp(String generatedOtp, String enteredOtp) {
		if(generatedOtp.equals(enteredOtp)) {
		return true;
	}else {
		return false;
	}
	}
      
}