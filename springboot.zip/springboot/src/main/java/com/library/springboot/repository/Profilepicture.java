package com.library.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.springboot.entities.ProfilePicture;

public interface Profilepicture extends JpaRepository<ProfilePicture , Integer>{

}