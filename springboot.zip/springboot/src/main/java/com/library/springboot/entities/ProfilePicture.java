package com.library.springboot.entities;





import java.util.Arrays;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToOne;
@Entity
public class ProfilePicture {

	  @Id
	   @GeneratedValue(strategy=GenerationType.AUTO)
	 private int id;
	  @Lob
	 private byte image[];
	 
	 @OneToOne
	 @JoinColumn(name="admin")
	 private Admin admin;

	public ProfilePicture() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProfilePicture(int id, byte[] image, Admin admin) {
		super();
		this.id = id;
		this.image = image;
		this.admin = admin;
	}

	@Override
	public String toString() {
		return "ProfilePicture [id=" + id + ", image=" + Arrays.toString(image) + ", admin=" + admin + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	 
	 
	
	}