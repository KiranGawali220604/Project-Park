package com.library.springboot.entities;


import java.sql.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Transient;
@Entity
public class Admin {
	
   @Id
   @GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String firstname;
	private String lastname;
	private Date birthday;
	private String password;
	private String contact;
	private String email;

	@Transient
	private String otp;
	
	 @OneToOne(mappedBy="admin" ,cascade = CascadeType.ALL)
		private ProfilePicture profilePicture;

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(int id, String firstname, String lastname, Date birthday, String password, String contact,
			String email, String otp, ProfilePicture profilePicture) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.birthday = birthday;
		this.password = password;
		this.contact = contact;
		this.email = email;
		this.otp = otp;
		this.profilePicture = profilePicture;
	}

	@Override
	public String toString() {
		return "Admin [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", birthday=" + birthday
				+ ", password=" + password + ", contact=" + contact + ", email=" + email + ", otp=" + otp
				+ ", profilePicture=" + profilePicture + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public ProfilePicture getProfilePicture() {
		return profilePicture;
	}

	public void setProfilePicture(ProfilePicture profilePicture) {
		this.profilePicture = profilePicture;
	}

	
	
	
	}